/*:
 ## Exercise: Making a List
 
 Lists are great. Here are some constants describing some of the things you’ve learned about strings so far:
 */
let constants = "Declaring string constants"
let unicode = "Unicode characters (😎)"
let combining = "Combining strings using +"
let interpolation = "String interpolation (aka Fill in the Blanks)"
let escaping = "Escape characters for \"special powers\""
let newline = "Making new lines"
/*:
 - experiment: Make a new string constant that is a list of the things you’ve learned, with each entry on a new line. Make sure you add the result to the playground page so that you can see the list properly.
 */
//constant (c is the constant)
let c = "Constant, declaring string constants"
//defing string and number constants have just a number for the string
let defineString = "constant string has quotation makes between them" 
//combing strings
let combine = "string are able to be combined by using the + sign and combine 2 constants"
//stringinterception
let interceptionString = "capable of completeing setence on a string with diffrent constants (fill blank)"
//escaping
let escaping = "escaping charters for \"special powers\""




//:
//:[Previous](@previous)  |  page 13 of 16  |  [Next: Exercise: A Restaurant](@next)
